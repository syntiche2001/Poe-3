﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace RecipeBookGUI_PPOE
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
